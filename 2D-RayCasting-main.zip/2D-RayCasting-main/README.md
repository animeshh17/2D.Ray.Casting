# 2D-RayCasting
Ray tracing algorithm that shoots one or more rays from the camera (eye position) through each pixel in an image plane, and then tests to see if the rays intersect any primitives (lines, polygons) in the scene.
